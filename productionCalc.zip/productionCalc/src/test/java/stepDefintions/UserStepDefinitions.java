package stepDefintions;
import info.seleniumcucumber.methods.BaseTest;

public class UserStepDefinitions implements BaseTest {

}
